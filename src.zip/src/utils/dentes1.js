const dentes1 = [
    {
        numDente: "18",
        caminhoImg: '18.png'
    },
    {
        numDente: "17",
        caminhoImg: "17.png"
    },
    {
        numDente: "16",
        caminhoImg: "16.png"
    },
    {
        numDente: "15",
        caminhoImg: "15.png"
    },
    {
        numDente: "14",
        caminhoImg: "14.png"
    },
    {
        numDente: "13",
        caminhoImg: "13.png"
    },
    {
        numDente: "12",
        caminhoImg: "12.png"
    },
    {
        numDente: "11",
        caminhoImg: "11.png"
    },
    {
        numDente: "21",
        caminhoImg: "21.png"
    },
    {
        numDente: "22",
        caminhoImg: "22.png"
    },
    {
        numDente: "23",
        caminhoImg: "23.png"
    },
    {
        numDente: "24",
        caminhoImg: "24.png"
    },
    {
        numDente: "25",
        caminhoImg: "25.png"
    },
    {
        numDente: "26",
        caminhoImg: "26.png"
    },
    {
        numDente: "27",
        caminhoImg: "27.png"
    },
    {
        numDente: "28",
        caminhoImg: "28.png"
    }
]


export default dentes1


