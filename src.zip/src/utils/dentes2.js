const dentes2 = [
    {
        "numDente": "48",
        "caminhoImg": "48.png"
    },
    {
        "numDente": "47",
        "caminhoImg": "47.png"
    },
    {
        "numDente": "46",
        "caminhoImg": "46.png"
    },
    {
        "numDente": "45",
        "caminhoImg": "45.png"
    },
    {
        "numDente": "44",
        "caminhoImg": "44.png"
    },
    {
        "numDente": "43",
        "caminhoImg": "43.png"
    },
    {
        "numDente": "42",
        "caminhoImg": "42.png"
    },
    {
        "numDente": "41",
        "caminhoImg": "41.png"
    },
    {
        "numDente": "31",
        "caminhoImg": "31.png"
    },
    {
        "numDente": "32",
        "caminhoImg": "32.png"
    },
    {
        "numDente": "33",
        "caminhoImg": "33.png"
    },
    {
        "numDente": "34",
        "caminhoImg": "34.png"
    },
    {
        "numDente": "35",
        "caminhoImg": "35.png"
    },
    {
        "numDente": "36",
        "caminhoImg": "36.png"
    },
    {
        "numDente": "37",
        "caminhoImg": "37.png"
    },
    {
        "numDente": "38",
        "caminhoImg": "38.png"
    }
]

export default dentes2

